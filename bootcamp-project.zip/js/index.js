$("#WIM_WENDERS").hide();
$("button").click(function(){
    $("#bottom-right").fadeOut();
    $("#WIM_WENDERS").fadeIn();
      $("button").click(function(){
        $("#bottom-right").fadeIn()});
  });